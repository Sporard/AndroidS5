package com.example.pierre.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

   // @Override
    int random;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button boutonRNG = (Button) findViewById(R.id.buttonRNG);
        final TextView editText = (TextView) findViewById(R.id.CentralText);
        final Button boutonAdd = (Button) findViewById(R.id.buttonAdd);
        boutonAdd.setOnClickListener(new View.OnClickListener(){
                @Override
            public void onClick(View v){
                    startActivity(new Intent(MainActivity.this,AjoutActivity.class));
                }

        });


        boutonRNG.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                String[] fais_la_rng = {"DOMAC","KFC","KEBAB","BURGER KING","FRENCHY"};
                random = (int)(Math.random()*fais_la_rng.length);
                editText.setText(fais_la_rng[random] );
            }
        });

    }
}
