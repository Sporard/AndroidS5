package com.example.pierre.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import org.json.*;

public class AjoutActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout);

        final Button boutonRetour = (Button) findViewById(R.id.buttonRetour);
        final TextView editText = (TextView) findViewById(R.id.CentralText);
        final TableLayout tableau = (TableLayout) findViewById(R.id.tab);
        TableRow row;
        TextView v1,v2;
    try {

         JSONObject dico = new JSONObject("dico.json");
        // JSONArray liste = dico.getJSONArray("name");
        // for(int i = 0; i<liste.length();i++){
         //    row = new TableRow(this);
          //   v1 = new TextView(this);
            // v1.setText(liste.getString(i));
             //row.addView(v1);
            // tableau.addView(row);
        //}
        editText.setText(dico.toString());

    } catch(JSONException e){
        Log.e("MYAPP","Unexpected JSon exception",e);
    }


        boutonRetour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AjoutActivity.this, MainActivity.class));
            }

        });

    }
}
